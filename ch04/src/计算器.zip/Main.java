package 计算器;

public class Main {
    public static void main(String[] args) {
        calculator sp=new calculator();
        Number s= new Number();
        sp.setVisible(true);
    }
}
